"""TextStats product tests, independent of coordinator workflow fixtures."""
