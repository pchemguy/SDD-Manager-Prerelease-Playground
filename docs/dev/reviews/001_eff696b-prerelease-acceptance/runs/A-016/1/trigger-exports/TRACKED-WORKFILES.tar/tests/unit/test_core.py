"""Exercise R-001/R-003/R-004/R-005 with independently specified counts."""

from dataclasses import FrozenInstanceError
import unittest

from textstats.core import TextStats, _count_normalized, _logical_lines, count_text


class StatisticsTests(unittest.TestCase):
    def test_value_equality_and_nonnegative_integers(self):
        self.assertEqual(TextStats(0, 0), TextStats(lines=0, words=0))
        self.assertNotEqual(TextStats(1, 2), TextStats(2, 1))
        self.assertEqual(TextStats(10**100, 3).lines, 10**100)

    def test_immutable_fields(self):
        value = TextStats(1, 2)
        for field in ("lines", "words"):
            with self.subTest(field=field), self.assertRaises(FrozenInstanceError):
                setattr(value, field, 4)
            with self.subTest(delete=field), self.assertRaises(FrozenInstanceError):
                delattr(value, field)

    def test_negative_counts_rejected(self):
        for counts in ((-1, 0), (0, -1), (-1, -1)):
            with self.subTest(counts=counts), self.assertRaises(ValueError):
                TextStats(*counts)

    def test_noninteger_counts_rejected_in_either_field(self):
        for invalid in (True, False, 1.0, "1", None, [], complex(1)):
            for counts in ((invalid, 0), (0, invalid)):
                with self.subTest(counts=counts), self.assertRaises(TypeError):
                    TextStats(*counts)


class CountingTests(unittest.TestCase):
    def test_shared_traversal_preserves_content_and_terminators(self):
        text = "a\r\n\rb\u2028c\nlast"
        self.assertEqual(list(_logical_lines(text)), ["a\r\n", "\r", "b\u2028c\n", "last"])
        self.assertEqual(list(_logical_lines("")), [])
        self.assertEqual(list(_logical_lines("\n")), ["\n"])

    def test_already_normalized_counting_retains_exposed_bom(self):
        self.assertEqual(_count_normalized("\ufeff"), TextStats(1, 1))

    def test_whole_input_spec_matrix_both_policies(self):
        cases = (
            ("", (0, 0), (0, 0)),
            ("alpha beta", (1, 2), (1, 2)),
            ("alpha\n", (1, 1), (1, 1)),
            ("\n", (1, 0), (1, 0)),
            ("alpha\r\nbeta\rgamma\n", (3, 3), (3, 3)),
            ("alpha\n\n", (2, 1), (2, 1)),
            (" \t", (1, 0), (1, 0)),
            ("alpha\u2028beta", (1, 2), (1, 2)),
            ("\ufeff", (0, 0), (1, 1)),
            ("\ufeff\ufeff", (1, 1), (1, 1)),
            ("\ufeffalpha beta", (1, 2), (1, 2)),
            ("a\ufeffb", (1, 1), (1, 1)),
            ("\r\n", (1, 0), (1, 0)),
            ("\r", (1, 0), (1, 0)),
        )
        for text, stripped, retained in cases:
            for policy, expected in ((True, stripped), (False, retained)):
                with self.subTest(text=text, strip_bom=policy):
                    self.assertEqual(count_text(text, strip_bom=policy), TextStats(*expected))

    def test_unicode_whitespace_does_not_broaden_line_terminators(self):
        text = "α\u0085β\u2028γ\u2029δ\vε\fζ\u00a0η\u2003θ"
        self.assertEqual(count_text(text), TextStats(1, 8))
        self.assertEqual(count_text("\u2028\u0085\u2029"), TextStats(1, 0))

    def test_mixed_terminators_and_final_segment(self):
        self.assertEqual(count_text("a\r\n\rb\n\nc"), TextStats(5, 3))
        self.assertEqual(count_text("\r\n\r\n"), TextStats(2, 0))
        self.assertEqual(count_text("\r\n\r"), TextStats(2, 0))

    def test_repeated_and_interior_boms_remain_words(self):
        self.assertEqual(count_text("\ufeff\ufeff\n"), TextStats(1, 1))
        self.assertEqual(count_text("\ufeff\n\ufeff"), TextStats(2, 1))
        self.assertEqual(count_text("a \ufeff b"), TextStats(1, 3))


if __name__ == "__main__":
    unittest.main()
