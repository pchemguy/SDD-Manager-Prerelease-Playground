"""Pure whole-text counting with CRLF/CR/LF lines and Unicode word whitespace.

Normalization is separate from traversal and normalized counting so future
line selection can reuse the same boundaries without stripping a BOM twice.
"""

from collections.abc import Iterator
from dataclasses import dataclass


@dataclass(frozen=True)
class TextStats:
    """Immutable, equal-by-value nonnegative integer line and word counts.

    Raises:
        TypeError: Either count is not an integer, or is a boolean.
        ValueError: Either count is negative.
    """

    lines: int
    words: int

    def __post_init__(self) -> None:
        for name, value in (("lines", self.lines), ("words", self.words)):
            if not isinstance(value, int) or isinstance(value, bool):
                raise TypeError(f"{name} must be an integer, excluding bool")
            if value < 0:
                raise ValueError(f"{name} must be nonnegative")


def _normalize_text(text: str, strip_bom: bool) -> str:
    """Remove exactly one leading BOM when requested; preserve all other text."""
    if strip_bom and text.startswith("\ufeff"):
        return text[1:]
    return text


def _logical_lines(text: str) -> Iterator[str]:
    """Yield original segments terminated only by CRLF, CR or LF.

    Terminators stay attached; empty input and a trailing phantom segment yield
    nothing. Unicode separators are ordinary segment content.
    """
    start = index = 0
    while index < len(text):
        character = text[index]
        index += 1
        if character == "\r":
            if index < len(text) and text[index] == "\n":
                index += 1
        elif character != "\n":
            continue
        yield text[start:index]
        start = index
    if start < len(text):
        yield text[start:]


def _count_normalized(text: str) -> TextStats:
    """Count already normalized content without applying any BOM policy."""
    return TextStats(sum(1 for _ in _logical_lines(text)), len(text.split()))


def count_text(text: str, *, strip_bom: bool = True) -> TextStats:
    """Return whole-input statistics silently, without modifying input.

    Args:
        text: Complete text to count. CRLF, CR and LF terminate lines;
            other Unicode separators affect words only through str.split().
        strip_bom: Remove exactly one leading U+FEFF by default. False retains
            every BOM as ordinary non-whitespace.

    Returns:
        Immutable line and word counts. A nonempty unterminated final segment
        contributes one line; a trailing terminator adds no phantom line.
    """
    return _count_normalized(_normalize_text(text, strip_bom))
