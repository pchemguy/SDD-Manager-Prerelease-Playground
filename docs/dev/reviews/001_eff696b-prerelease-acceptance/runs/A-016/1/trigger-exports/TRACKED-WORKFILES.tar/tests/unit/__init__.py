"""Pure component contract tests."""
