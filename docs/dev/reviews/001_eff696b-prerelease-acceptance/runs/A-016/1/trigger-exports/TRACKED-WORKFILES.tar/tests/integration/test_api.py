"""Verify the delivered public text API, signature and silence."""

import contextlib
import inspect
import io
import unittest

from textstats import TextStats, count_text


class PublicTextTests(unittest.TestCase):
    def test_direct_exports_are_core_values(self):
        from textstats.core import TextStats as CoreStats, count_text as core_count
        self.assertIs(TextStats, CoreStats)
        self.assertIs(count_text, core_count)

    def test_signature_is_whole_input_and_keyword_only_policy(self):
        signature = inspect.signature(count_text)
        self.assertEqual(list(signature.parameters), ["text", "strip_bom"])
        self.assertEqual(signature.parameters["text"].annotation, str)
        self.assertEqual(signature.parameters["strip_bom"].annotation, bool)
        self.assertIs(signature.parameters["strip_bom"].default, True)
        self.assertEqual(signature.parameters["strip_bom"].kind, inspect.Parameter.KEYWORD_ONLY)
        self.assertIs(signature.return_annotation, TextStats)
        with self.assertRaises(TypeError):
            count_text("a", False)

    def test_public_counts_default_policy_and_silence(self):
        stdout, stderr = io.StringIO(), io.StringIO()
        with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            default = count_text("\ufeff\r\nα β\rγ\n")
            retaining = count_text("\ufeff\r\nα β\rγ\n", strip_bom=False)
        self.assertEqual(default, TextStats(3, 3))
        self.assertEqual(retaining, TextStats(3, 4))
        self.assertEqual(stdout.getvalue(), "")
        self.assertEqual(stderr.getvalue(), "")


if __name__ == "__main__":
    unittest.main()
