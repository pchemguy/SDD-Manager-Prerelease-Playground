"""Public TextStats boundary tests."""
