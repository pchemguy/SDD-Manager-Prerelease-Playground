"""Silent whole-text statistics API. Named-file support is not delivered yet."""

from .core import TextStats, count_text

__all__ = ["TextStats", "count_text"]
