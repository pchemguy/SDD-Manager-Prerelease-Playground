# Coordinate development-document QC gates

Load **sdd-conventions**' **Development-document QC** reference (`skills/sdd-conventions/references/development-document-qc.md`, bundled dependency) for canonical count/conformance/report/readiness rules. Artifact owners assess readiness; sdd-manage schedules reviews, routes corrections and enforces dependent-stage gates. **sdd-report**'s **Document QC reports** reference composes adjacent reports from their actual evidence.

## Stage handoff

| Completed input | Required owner assessment | Dependent operation |
| --- | --- | --- |
| SPEC / FEATURE-SPEC and applicable children | sdd-specify: accepted PROJECT/design conformance | PLAN / dependent feature planning |
| PLAN / FEATURE-PLAN with relevant layout | sdd-plan: SPEC conformance and phase/milestone decomposition | TASKS / dependent feature tasks |
| TASKS / FEATURE-TASKS and applicable children | sdd-tasks: PLAN conformance, scope and task hierarchy | Implementation or creation/projection of hosted task objects |

1. Establish the selected document/feature scope, accepted governing inputs, authorized effects and stopping point. Authoring includes its scoped QC correction/recheck and report; read-only review returns findings without silently correcting sources. Literal selected-path-only restrictions prevail; missing required report permission is a concrete scope blocker, not permission to widen paths.
2. At entry and each dependent transition, compare actual root/children/upstream state with current review evidence, finding dispositions, scope/coverage and readiness. Reuse demonstrably current equivalent reviews; explain materiality/equivalence from actual differences. A Ready label, file presence or a historical feature review is insufficient alone. Do not fabricate a review for an older project.
3. Obtain the focused missing assessment through the relevant owner within the already authorized scope. Creation/revision of an artifact includes review, authorized bounded corrections, recheck and report persistence before downstream progression. Use existing requirement/component IDs and grouped coverage; no new administrative milestones or task chain is needed for preparation QC.
4. Route missing design/behavior/strategy decisions upstream. Do not revise SPEC to excuse PLAN omissions or PLAN to accommodate accidental TASKS strategy. The owner may resolve routine choices already authorized; ask only for a genuinely missing consequential decision. Preserve read-only limits and unselected owners.
5. Have the owner produce the adjacent root report with current identities, coverage/count assessments, original findings, appended Revision N rechecks and Ready/Blocked evidence. Corrected artifacts and their report are one coherent preparation checkpoint under [coordination persistence](coordination.md#persist-repository-changes). Do not progress on a draft report, unpersisted required boundary or deferred confirmed issue. Honor explicit local-only publication limits; report any established dependent requirement for unavailable remote evidence separately.
6. For a blocked input, identify the finding, actual owner, needed correction/review scope and blocked dependent operation. Continue only independent authorized work. Explicit human exceptions name scope/consequences without relabeling Blocked as Ready or bypassing implementation acceptance.

## Amendments, scope and continuation

Readiness and branch integration are separate gates. Persist project preparation artifacts and adjacent QC reports together on design-docs. Before creating a dependent implementation branch, the manager completes [preparation integration](branch-management.md#preparation-integration-gate) into the repository default branch, verifies the merged state and publishes it. A Ready report or design-docs push alone does not satisfy that baseline. Campaign plans/reports retain their revision-branch ownership.

Material changes to design, behavior, strategy, hierarchy/dependencies or layout invalidate affected downstream review until rechecked. Recheck only impacted concerns; routine completion status/evidence updates alone need not invalidate unchanged conformance. Initial preparation and focused direct calls use the same gate. Main/feature task execution still pushes outstanding commits before other task work; readiness review follows that prerequisite and precedes new execution/phase projection.

sdd-integrate-feature and sdd-steer retain their accepted correction ownership. Coordinate owners' focused assessment of changed main/feature documents and their adjacent reports before dependent use. A SPEC-only incorporation does not authorize unselected TASKS/PLAN edits: report their invalidation and keep those downstream gates blocked until their separately authorized recheck. It can finish its coherent selected incorporation without claiming whole-project readiness.

Feature QC reports stay adjacent to their active roots and, when eligible/in scope, archived sources. Implementation reports retain their lifecycle phase/feature prefixes. Preserve scope, report/source identity, original findings and review history during moves; archive readiness is historical, not current main-document acceptance.

After interruption, inspect files, report source identities, pending corrections, index and commits. Finish the same correction/recheck/report/push without regenerating valid documents or duplicating Revision sections. Do not mark a gate Ready from a lost response, checkbox or commit subject. No new transaction journal is required.

## Human acceptance alongside QC

Apply [human document review](human-document-review.md) independently of technical Ready/Blocked. Each necessary new root/proposal pauses for human review before dependent progression, including direct calls and feature deltas. Existing acceptable startup inputs need no retrospective interactive review; requested review and actual pending human boundaries remain binding.

For a newly created PLAN awaiting new layout, assess/persist strategy-scoped QC and explicitly state pending layout/TASKS readiness. Review PLAN with the human before dependent layout authoring. After layout is prepared, complete affected combined PLAN/layout QC in the adjacent PLAN report and hold TASKS for the distinct human layout checkpoint. Do not misrepresent strategy-only Ready as combined readiness.
