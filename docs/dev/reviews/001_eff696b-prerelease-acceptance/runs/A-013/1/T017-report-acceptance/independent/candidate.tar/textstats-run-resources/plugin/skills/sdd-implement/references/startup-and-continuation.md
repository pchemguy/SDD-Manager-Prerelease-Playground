# Startup and continuation

## Push before task work

Use the current **sdd-orient** handoff to establish the eligible Git worktree, current branch, HEAD, governing instructions, and pending-change ownership. Resolve the established remote destination from repository policy and branch configuration. This prerequisite inspection enables the first execution action: push outstanding commits before any task selection, check execution, or edit.

Check the current branch against the established remote branch and push all unpushed commits, independently of worktree cleanliness. Verify that the remote contains those commits; when no new remote changes occurred, its branch tip should match local HEAD. If no commits are outstanding, continue without creating a push solely for ceremony. Do not force-push, guess a destination, initialize Git, or reset pending work. Report missing destination, access failure, detached or unusable branch state, or divergence that prevents the required push; stop further implementation until resolved.

Attempt the required push with existing shell authentication; do not discover/request tokens first. On a 403 or explicit credential failure, pass sanitized destination, transport, operation, and cause to **sdd-manage**'s **Hosting credentials** protocol for recovery and retry. Confirm remote containment before proceeding; unresolved access remains a push blocker.

## Interpret the startup task state

| Observed state | Action |
| --- | --- |
| Checked task or parent has a pending completion reassessment | After startup pushing, assess its current acceptance within the authorized range; correct unsupported status, preserve historical evidence, and retain the note until reassessment is resolved. Report out-of-range work as a scope conflict. |
| Last checked task is ahead of the last completed task commit | Confirm task ownership and existing completion evidence, finish its commit and push, and coordinate its issue closure. Do not reimplement completed work. |
| Current task is unchecked with task-owned pending changes | Inspect existing work and resume the remaining implementation and verification. |
| Clean tree and checklist agrees with committed task boundary | Select eligible work within the requested range; do not treat cleanliness as proof that required issue closure has occurred. |
| Missing or contradictory completion evidence | Obtain the missing checks or repair incomplete work within scope before treating the task as complete. |
| Ambiguous task identity, ownership, or conflicting changes | Preserve changes and report the ambiguity before mutating the affected work. |

Use the last task commit as the historical completed boundary; later maintenance, reconciliation, or steering-amendment commits do not establish another completed task. A pending reassessment disputes current acceptance without erasing that history. Preserve stable IDs in the owning TASKS or FEATURE-TASKS. If no task has been committed, use the established preimplementation baseline.

Continuation finishes the interrupted task before new task selection. If it falls outside the newly requested range or the user directs a conflicting action, report the scope conflict rather than silently expanding or discarding work. Apply the shared [backend object lifecycle](../../sdd-conventions/references/backend-object-lifecycle.md): inspect pending milestone closures, report persistence, local parent reconciliation and phase integration before replaying transitions. Recover exact object/report identities, verify uncertain effects and finish the earliest unmet authorized transition. Do not repeat a completed review or activate a new phase while predecessor closure/publication is pending.

When hosted tracking is active, check pending references and closures for verified completed tasks within the established maintained tracking scope through **sdd-forge** as part of normal completion processing, including older tasks completed while hosting was unavailable. Do not limit reconciliation to the resumed or latest task or infer completion from hosted state. Hosting unavailability permits further independent task execution only inside an already verified activated phase, for tasks whose projection and dependencies are satisfied. It does not waive missing initial or added-work projection, dependent review/closure or next-phase gates. Preserve and publish retained verified results; report hosted closure pending. An actual explicit human override is required to cross an unmet tracking gate in local-only mode.

## Select the authorized range

Use [range selection](range-selection.md) to resolve task, next-N-task, milestone, or phase requests into precise IDs, prerequisite evidence, and exit conditions. For feature work, select from the active FEATURE-TASKS and inspect relevant TASKS prerequisites; for main work, use TASKS. Report ambiguous active scope and unmet out-of-range prerequisites rather than selecting silently.

Keep the selected range and checkpoint visible throughout execution. A user may change the range or pause work; preserve completed commits and current pending work, report the new boundary, and follow the latest instruction. A separate steering request does not authorize automatic continuation afterward.

## Working branch and integration continuation

Before creating a new dependent implementation branch, require **sdd-manage**'s [preparation integration gate](../../sdd-manage/references/branch-management.md#preparation-integration-gate): project preparation and required QC reports committed on design-docs, accepted tip explicitly merged into the actual default branch, merged state verified, target published and containment confirmed. Create the phase/feature execution branch from that default checkpoint afterward. Ready reports, local merges and a design-docs push are insufficient. A failed prerequisite prevents branch creation and task execution; retain the document/merge state. Campaign plans/reports remain on revision branches. For a continued revision needing project preparation, integrate the published default baseline into its existing campaign branch before source execution; preserve in-flight implementation and raise incompatible histories rather than resetting them.

After startup pushing, establish or reuse the selected range's working branch and target under **sdd-manage**'s **Branch management** reference. Record its starting checkpoint in existing task/change evidence. Load [tracking decision](../../sdd-manage/references/tracking-decision.md) and [phase activation](../../sdd-manage/references/phase-activation.md) before further task edits/tests, including a resumed task with a missed prerequisite. Creating an implementation branch alone does not establish hosted readiness. Requested/confirmed tracking with missing/partial/unknown projection is a blocker; preserve work and apply the manager's [omission recovery](../../sdd-manage/references/tracking-decision.md#recover-an-omitted-requested-gate), not an implicit downgrade. Preserve unfinished task ownership before branch setup; do not create a new branch to evade pending work or push blockers. On continuation, distinguish unfinished tasks, completed tasks awaiting commit/push, an uncommitted merge awaiting conflict repair or verification, and a verified merge awaiting target publication. Finish the authorized state rather than repeating tasks or merging again. Ambiguous branch/target identities or out-of-range work block the affected continuation.

## Check the claimed task closing boundary

Apply the [task persistence audit and recovery](completion-and-checkpoints.md#task-persistence-audit-and-recovery) to the latest claimed closing task and selected pending work after startup publication and before advancing. Inspect its actual subject, result/evidence and owning checklist transition. Do not treat an aggregate multi-task commit, detached checkbox commit or malformed subject as a compliant closing boundary. Preserve verified published work; report affected identities and diffs to the manager for scoped recovery rather than automatically rewriting history or replaying implementation.

## Current preparation inputs

After pushing outstanding commits and reconciling pending state, use **sdd-manage**'s **Document QC gates** reference before new task execution or hosted projection. Inspect current owning task/design/SPEC/PLAN/layout review scope and evidence; ordinary completion status updates alone do not invalidate unchanged contract/decomposition review. Do not use a stale Ready label to resume changed requirements or select a guessed repair scope. Coordinate focused missing review within existing authorization; report a correction requiring new decisions or paths as a blocker. This does not postpone publication of an already verified committed result or authorize new implementation while resolving readiness.

## Optional tracking decision at handoff

Use **sdd-manage**'s [tracking decision](../../sdd-manage/references/tracking-decision.md) before dependent phase activation. Carry the recommendation, actual confirmation/decline, repository/scope and observed hosted state separately. A supplied GitHub token recommends enabled tracking but does not activate it; unresolved activation choices return to the manager. Reuse confirmed scope without repeated approval. Late confirmation reconciles retained evidence instead of replaying product tasks.

## Scoped authority handoff

Carry the existing request, destination/ref or hosted identity, payload scope, checks and explicit limits through the manager's [coordination handoff](../../sdd-manage/references/coordination.md#coordinate-execution). Keep credentials protected and optional tracking decisions separate. Preserve blocked publication under [Git recovery](../../sdd-manage/references/git-workflows.md#platform-authorization-rejection).

## Environment readiness

For observed installation/runtime blockers, use [environment recovery](environment-recovery.md) after the push-first prerequisite. Return actual attempts, supported alternatives and remaining required capabilities to the manager. Browser detail is conditional; ordinary engine/CLI work loads no browser prerequisites.
