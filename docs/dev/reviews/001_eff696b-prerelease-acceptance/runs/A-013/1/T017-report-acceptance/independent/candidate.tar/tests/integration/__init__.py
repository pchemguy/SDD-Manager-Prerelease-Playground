"""Public API integration tests."""
