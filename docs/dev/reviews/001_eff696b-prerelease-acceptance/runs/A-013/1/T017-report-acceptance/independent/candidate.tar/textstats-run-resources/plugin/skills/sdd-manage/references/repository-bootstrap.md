# Bootstrap SDD Manager in a target repository

## Greenfield startup

Load this section at greenfield entry, before the first persistence operation. Treat a preliminary project description as a seed for exploration, not an accepted specification. Use the current **sdd-orient** handoff to establish the eligible Git repository, controlling instructions and actual state; route problem framing, alternatives and consequential choices to **sdd-design**'s [exploration](../../sdd-design/references/exploration.md). Retain established decisions and identify assumptions without imposing an unrequested product, stack or feature set.

Carry the supplied repository, project scope, stopping boundary and explicit repository-operation authorization into [coordination](coordination.md). Apply the existing [workflows](workflows.md) and [document QC gates](document-qc-gates.md) for acceptance and execution boundaries, and [Git workflows](git-workflows.md) for complete checkpoint publication and synchronization. Ask for material missing information or consequential decisions; continue independent authorized work when sound. Standing repository authority does not accept proposed requirements or select an implementation range.

Treat an explicit request for GitHub phase labels, milestones and task issues as tracking confirmation under [tracking decision](tracking-decision.md); carry that choice without asking again. Delegate projection, associations and verified state updates to **sdd-forge** and [phase activation](phase-activation.md) at their eligible boundaries. Protect a supplied token through [hosting credentials](credentials.md); its technical permissions neither define project scope nor require unrelated operations.

The root [Greenfield Project Prompt Template](<../../../Greenfield Project Prompt Template.md>) supplies the user's project seed, repository/token inputs, standing authorization and tracking selection. The plugin owns startup and subsequent procedures. Continue through the requested stages and checkpoints; preserve preparation-only, local-only and explicit stop instructions. The disclosure/adoption trigger below remains the first authorized SDD commit, not the start of conversational exploration.

## Ownership and trigger

Before the **first authorized SDD commit** in a target repository, include the disclosure and usage notice below in that same commit. This includes initial document preparation or review records, not just the first implementation task. “Initial” means SDD adoption in an already eligible Git worktree; do not initialize Git implicitly. Read-only orientation, discussion, selection and verification create nothing.

**sdd-manage** owns this shared policy and coordinates bootstrap for preparation, maintenance and feature incorporation. **sdd-implement** and **sdd-steer** apply it in their own commit procedures, including direct invocations. **sdd-report** checks bootstrap evidence when composing a commit but does not write or commit files. Load this reference at greenfield entry and before the first persistence operation in other adoption workflows; it is an ordinary agent procedure, not a hidden hook or client installer.

For implementation, push outstanding commits first under the existing startup protocol, then perform bootstrap before staging the first new result. Do not make a separate bootstrap commit ahead of the requested result. A preparation-only request can bootstrap with its preparation commit and still stop before implementation.

## Root artifacts and discoverability

Ensure root AGENTS.md through [agent orientation](agent-orientation.md) during authorized adoption. Read existing controlling instructions first; preserve manual content and explicit path limits. Include affected orientation with the same first result checkpoint, not a separate administrative commit. Its ownership and subsequent maintenance are independent of disclosure byte-copy requirements.

Resolve assets relative to the loaded plugin root: this reference is at `skills/sdd-manage/references/repository-bootstrap.md`; bundled files are at `assets/AI_DISCLOSURE.md` and `assets/SDD-MANAGER.md`. Use the same installed or pinned source as the running skills, including an acceptance vendor snapshot. Do not fetch a newer template silently or fabricate a missing asset.

1. Inspect the target Git root, applicable instructions, root `AI_DISCLOSURE.md`, `SDD-MANAGER.md`, README and relevant Git history. Establish bootstrap ownership separately from unrelated pending content. For a project nested in a Git repository, place these records at the **target repository root**, not inside `docs/dev/` or the project subdirectory; resolve incompatible repository-wide scope before writing.
2. If absent, copy `assets/AI_DISCLOSURE.md` byte for byte to root `AI_DISCLOSURE.md` and `assets/SDD-MANAGER.md` to root `SDD-MANAGER.md`. The notice names SDD Manager and links `https://github.com/pchemguy/SDD-Manager`; it links the root disclosure and makes no unsupported completion claim. Never include credentials or local installation paths.
3. Add a concise discoverable root README link, preserving its project focus and existing text:

   `Development uses [SDD Manager](SDD-MANAGER.md). See the [AI-assisted development disclosure](AI_DISCLOSURE.md).`

   Reuse an existing equivalent link instead of duplicating it. If no root README exists, create a minimal `README.md` with the established project name and these links; do not invent product claims. Where the repository uses another designated root README, use that document and correct relative links.
4. Preserve existing disclosures and usage notices. If byte-identical, reuse them. If different, read and reconcile within authorized scope: retain project-specific disclosure and truthful attribution, add the required SDD Manager link, and do not replace established text with a template. An existing disclosure can satisfy the disclosure requirement if it expresses the project's AI assistance and maintainer responsibility; record why it was retained rather than claiming a byte-identical copy. Conflicting disclosure claims or ownership require a decision before the affected commit. Do not follow a symlink to edit an external file or directory.
5. Inspect links, truthful scope, file ownership and the staged diff. Include the owned root changes with the first verified SDD result and its ordinary status/evidence changes; apply the existing unrelated-index isolation, commit and push/readback rules. Verify the committed tree contains the required root records and README links, and an added disclosure matches its packaged bytes. A draft or untracked copy is not completion.

## Scope limits, recovery and upgrades

These files are ordinary bootstrap outputs of an authorized initial SDD workflow. Explicit human restrictions such as selected-path-only, no README edits, or read-only take precedence. If those restrictions exclude a required missing artifact, report the bootstrap scope conflict and obtain the missing decision rather than silently widening paths or falsely claiming bootstrap complete. Honor local-only/no-push instructions; bootstrap itself does not authorize publication.

On interruption, inspect actual files, index and Git evidence. Reuse valid pending copies in the same first result, preserving unrelated staged work. If the first SDD commit already includes the records, continue its pending push instead of making another bootstrap commit. On subsequent invocations, retain established files and links without duplicate sections or version churn. If an older SDD-managed repository lacks the records, add them to the next authorized coherent commit within scope and report this as adoption backfill; never rewrite history or claim they were in its original first commit. Report missing/conflicting records for scoped repair when their creation is not currently authorized.

A plugin update does not automatically overwrite the target's disclosure or notice. Version/commit provenance may be added when accurately known, but is not a prerequisite and must not misrepresent a dirty-source snapshot as a released version.

## Human review at startup

Apply [human document review](human-document-review.md) from greenfield entry. Walk the human through necessary new documents, pausing at each created root before dependent work. For existing or interrupted main/feature preparation, assess progress and reuse acceptable inputs without automatically entering interactive mode. Begin with explicitly requested interactive reviews; raise important startup concerns and offer review before advancing. Retain real pending review/stopping instructions.
