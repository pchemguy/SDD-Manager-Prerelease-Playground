"""Pure product contract tests."""
