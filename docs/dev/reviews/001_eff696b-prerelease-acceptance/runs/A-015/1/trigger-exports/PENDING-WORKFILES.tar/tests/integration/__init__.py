"""Public product boundary tests."""
