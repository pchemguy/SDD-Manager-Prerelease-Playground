"""Whole-input counts and immutable statistics under SPEC R-001–R-005."""
from dataclasses import FrozenInstanceError
import unittest

from textstats import TextStats, count_text


class TextCountingTests(unittest.TestCase):
    def test_whole_input_spec_matrix_under_both_policies(self):
        cases = [
            ("", (0, 0), (0, 0)),
            ("alpha beta", (1, 2), (1, 2)),
            ("alpha\n", (1, 1), (1, 1)),
            ("\n", (1, 0), (1, 0)),
            ("alpha\r\nbeta\rgamma\n", (3, 3), (3, 3)),
            ("alpha\n\n", (2, 1), (2, 1)),
            (" \t", (1, 0), (1, 0)),
            ("alpha\u2028beta", (1, 2), (1, 2)),
            ("\ufeff", (0, 0), (1, 1)),
            ("\ufeff\ufeff", (1, 1), (1, 1)),
            ("\ufeffalpha beta", (1, 2), (1, 2)),
            ("a\ufeffb", (1, 1), (1, 1)),
            ("\r\n", (1, 0), (1, 0)),
            ("\r", (1, 0), (1, 0)),
        ]
        for text, stripped, retained in cases:
            for strip, expected in [(True, stripped), (False, retained)]:
                with self.subTest(text=text, strip_bom=strip):
                    self.assertEqual(count_text(text, strip_bom=strip), TextStats(*expected))

    def test_unicode_whitespace_does_not_broaden_line_terminators(self):
        for separator in ["\u0085", "\u2028", "\u2029", "\u00a0", "\u2003", "\v", "\f"]:
            with self.subTest(separator=separator):
                self.assertEqual(count_text("α" + separator + "β"), TextStats(1, 2))
        self.assertEqual(count_text(" \t\u2003\n\r\n\r"), TextStats(3, 0))

    def test_mixed_and_consecutive_terminators_and_final_segment(self):
        for text, expected in [("a\r\nb\rc\nd", (4, 4)), ("\r\n\r\n", (2, 0)),
                               ("\n\r\n\r", (3, 0)), ("a\r\n\nb", (3, 2))]:
            with self.subTest(text=text):
                self.assertEqual(count_text(text), TextStats(*expected))

    def test_only_one_leading_bom_is_removed(self):
        self.assertEqual(count_text("\ufeff\ufeff\ufeff"), TextStats(1, 1))
        self.assertEqual(count_text("\ufeff\ufeff\n"), TextStats(1, 1))
        self.assertEqual(count_text("\ufeff\n"), TextStats(1, 0))
        self.assertEqual(count_text("\ufeff\n", strip_bom=False), TextStats(1, 1))
        self.assertEqual(count_text("a\n\ufeff"), TextStats(2, 2))


class StatisticsTests(unittest.TestCase):
    def test_valid_values_have_value_equality(self):
        self.assertEqual(TextStats(0, 0), TextStats(lines=0, words=0))
        self.assertEqual(TextStats(3, 7), TextStats(3, 7))
        self.assertNotEqual(TextStats(3, 7), TextStats(7, 3))
        self.assertEqual((TextStats(3, 7).lines, TextStats(3, 7).words), (3, 7))

    def test_fields_cannot_be_assigned_or_deleted(self):
        result = TextStats(3, 7)
        for name in ["lines", "words"]:
            with self.subTest(field=name):
                with self.assertRaises(FrozenInstanceError):
                    setattr(result, name, 9)
                with self.assertRaises(FrozenInstanceError):
                    delattr(result, name)
        self.assertEqual(result, TextStats(3, 7))

    def test_negative_counts_are_rejected_in_either_field(self):
        for counts in [(-1, 0), (0, -1), (-1, -1)]:
            with self.subTest(counts=counts):
                with self.assertRaises(ValueError):
                    TextStats(*counts)

    def test_non_integer_and_boolean_counts_are_rejected_in_either_field(self):
        for invalid in [True, False, 1.0, -1.0, "1", None, [], object()]:
            for counts in [(invalid, 0), (0, invalid)]:
                with self.subTest(counts=counts):
                    with self.assertRaises(TypeError):
                        TextStats(*counts)
